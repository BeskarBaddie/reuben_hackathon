import { useState } from 'react';
import { Link, useLocation } from 'react-router';
import {
  LayoutDashboard,
  Sprout,
  BarChart2,
  Lightbulb,
  Settings,
  Menu,
  X,
  Leaf,
  ChevronRight,
} from 'lucide-react';

const navItems = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/farms', label: 'Farms', icon: Sprout },
  { path: '/settings', label: 'Settings', icon: Settings },
];

interface AppShellProps {
  children: React.ReactNode;
  breadcrumb?: { label: string; href?: string }[];
  title?: string;
  actions?: React.ReactNode;
}

export function AppShell({ children, breadcrumb, title, actions }: AppShellProps) {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Sidebar */}
      <aside
        className={`
          fixed inset-y-0 left-0 z-50 w-56 flex flex-col
          transition-transform duration-200
          md:static md:translate-x-0
          ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
        style={{ background: 'var(--sidebar)' }}
      >
        {/* Logo */}
        <div className="flex items-center gap-2.5 px-4 h-14 border-b flex-shrink-0"
          style={{ borderColor: 'var(--sidebar-border)' }}>
          <div className="flex items-center justify-center w-7 h-7 rounded-md"
            style={{ background: 'var(--sidebar-primary)' }}>
            <Leaf className="w-4 h-4" style={{ color: 'var(--sidebar-primary-foreground)' }} />
          </div>
          <div>
            <p className="text-sm font-semibold leading-none" style={{ color: 'var(--sidebar-foreground)' }}>
              ClimateIQ
            </p>
            <p className="text-xs leading-none mt-0.5" style={{ color: 'var(--sidebar-accent-foreground)', opacity: 0.6 }}>
              Farm Intelligence
            </p>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-2 py-3 overflow-y-auto">
          <div className="mb-2 px-2">
            <p className="text-xs font-medium uppercase tracking-widest"
              style={{ color: 'var(--sidebar-foreground)', opacity: 0.4, fontFamily: 'var(--font-mono)' }}>
              Navigation
            </p>
          </div>
          {navItems.map(({ path, label, icon: Icon }) => {
            const isActive = path === '/'
              ? location.pathname === '/'
              : location.pathname.startsWith(path);
            return (
              <Link
                key={path}
                to={path}
                onClick={() => setMobileOpen(false)}
                className={`
                  flex items-center gap-2.5 px-3 py-2 rounded-md mb-0.5 text-sm transition-colors
                  ${isActive
                    ? 'font-medium'
                    : 'hover:opacity-80'}
                `}
                style={{
                  background: isActive ? 'var(--sidebar-accent)' : 'transparent',
                  color: isActive ? 'var(--sidebar-primary-foreground)' : 'var(--sidebar-foreground)',
                  opacity: isActive ? 1 : undefined,
                }}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                {label}
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="px-4 py-3 border-t" style={{ borderColor: 'var(--sidebar-border)' }}>
          <p className="text-xs" style={{ color: 'var(--sidebar-foreground)', opacity: 0.4, fontFamily: 'var(--font-mono)' }}>
            v0.1.0 · ClimateIQ
          </p>
        </div>
      </aside>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="flex items-center gap-3 px-4 md:px-6 h-14 bg-card border-b border-border flex-shrink-0">
          <button
            className="md:hidden p-1 rounded-md text-muted-foreground hover:text-foreground"
            onClick={() => setMobileOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex-1 min-w-0">
            {breadcrumb && breadcrumb.length > 0 ? (
              <nav className="flex items-center gap-1 text-sm text-muted-foreground">
                {breadcrumb.map((crumb, i) => (
                  <span key={i} className="flex items-center gap-1">
                    {i > 0 && <ChevronRight className="w-3 h-3 flex-shrink-0" />}
                    {crumb.href ? (
                      <Link to={crumb.href} className="hover:text-foreground truncate transition-colors">
                        {crumb.label}
                      </Link>
                    ) : (
                      <span className="text-foreground font-medium truncate">{crumb.label}</span>
                    )}
                  </span>
                ))}
              </nav>
            ) : title ? (
              <h1 className="text-foreground truncate">{title}</h1>
            ) : null}
          </div>

          {actions && <div className="flex items-center gap-2 flex-shrink-0">{actions}</div>}
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

export function PageContainer({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`px-4 md:px-6 py-6 max-w-7xl mx-auto ${className}`}>
      {children}
    </div>
  );
}
