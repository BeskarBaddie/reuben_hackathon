import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Lightbulb, Play, FileText, ChevronDown, ChevronUp } from 'lucide-react';
import { AppShell, PageContainer } from './AppShell';
import { ProviderBadge } from './shared/StatusBadge';
import { EmptyState, LoadingState } from './shared/EmptyState';
import { mockAnalyses, mockRecommendations, mockFarms } from '../mockData';

export function Recommendations() {
  const navigate = useNavigate();
  const { analysisId } = useParams<{ analysisId: string }>();
  const analysis = analysisId ? mockAnalyses[analysisId] : undefined;
  const farm = analysis ? mockFarms.find(f => f.farm_id === analysis.farm_id) : undefined;
  const recs = analysisId ? mockRecommendations[analysisId] : undefined;
  const [generating, setGenerating] = useState(false);
  const [expandedAction, setExpandedAction] = useState<number | null>(null);

  async function handleGenerate() {
    setGenerating(true);
    // POST /api/v1/analyses/{analysis_id}/recommendations
    await new Promise(r => setTimeout(r, 1500));
    setGenerating(false);
  }

  const breadcrumb = [
    { label: 'Farms', href: '/farms' },
    ...(farm ? [{ label: farm.name, href: `/farms/${farm.farm_id}` }] : []),
    ...(analysis ? [{ label: 'Analysis', href: `/analyses/${analysisId}` }] : []),
    { label: 'Recommendations' },
  ];

  return (
    <AppShell
      breadcrumb={breadcrumb}
      actions={
        <div className="flex items-center gap-2">
          {analysis && (
            <button
              onClick={() => navigate(`/analyses/${analysisId}`)}
              className="flex items-center gap-1.5 px-3 py-1.5 border border-border text-foreground bg-background rounded-md text-sm hover:bg-muted transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              View Report
            </button>
          )}
          <button
            onClick={handleGenerate}
            disabled={generating}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm hover:opacity-90 disabled:opacity-50 transition-opacity"
          >
            <Play className="w-3.5 h-3.5" />
            {generating ? 'Generating…' : 'Generate Recommendations'}
          </button>
        </div>
      }
    >
      <PageContainer>
        {generating ? (
          <LoadingState message="Generating recommendations from analysis data…" />
        ) : !recs ? (
          <EmptyState
            icon={Lightbulb}
            title="No recommendations yet"
            description="Run the recommendation engine to generate farmer-friendly adaptation actions for this analysis."
            action={
              <button
                onClick={handleGenerate}
                className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm hover:opacity-90"
              >
                <Play className="w-4 h-4" />
                Generate Recommendations
              </button>
            }
          />
        ) : (
          <div className="max-w-2xl">
            {/* Metadata header */}
            <div className="bg-card border border-border rounded-lg p-4 mb-4">
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <ProviderBadge provider={recs.provider} />
                <span className="text-xs text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
                  {recs.model_name}
                </span>
                <span className="text-xs text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
                  prompt {recs.prompt_version}
                </span>
                <span className="text-xs text-muted-foreground ml-auto">
                  {new Date(recs.generated_at).toLocaleDateString('en-GB', {
                    day: '2-digit', month: 'short', year: 'numeric',
                  })}
                </span>
              </div>
              <p className="text-sm text-foreground leading-relaxed">{recs.summary}</p>
            </div>

            {/* Actions list */}
            <div className="space-y-2">
              <h3 className="text-xs font-medium text-muted-foreground uppercase mb-3"
                style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.06em' }}>
                Recommended Actions ({recs.actions.length})
              </h3>
              {recs.actions.map((action, i) => {
                const isExpanded = expandedAction === i;
                return (
                  <div
                    key={i}
                    className="bg-card border border-border rounded-lg overflow-hidden"
                  >
                    <button
                      className="w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-muted/30 transition-colors"
                      onClick={() => setExpandedAction(isExpanded ? null : i)}
                    >
                      {/* Priority number */}
                      <span
                        className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full text-xs font-semibold mt-0.5"
                        style={{
                          background: action.priority === 1 ? 'var(--primary)' :
                            action.priority === 2 ? '#D97706' : 'var(--muted)',
                          color: action.priority <= 2 ? 'white' : 'var(--muted-foreground)',
                          fontFamily: 'var(--font-mono)',
                        }}
                      >
                        {action.priority}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground">{action.action}</p>
                      </div>
                      <span className="flex-shrink-0 text-muted-foreground mt-0.5">
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </span>
                    </button>

                    {isExpanded && (
                      <div className="px-4 pb-4 border-t border-border bg-muted/20">
                        <div className="pt-3 space-y-2">
                          <div>
                            <p className="text-xs text-muted-foreground uppercase mb-1"
                              style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.05em', fontSize: '10px' }}>
                              Why
                            </p>
                            <p className="text-sm text-foreground">{action.reason}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground uppercase mb-1"
                              style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.05em', fontSize: '10px' }}>
                              Evidence Used
                            </p>
                            <p className="text-xs text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
                              {action.evidence}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </PageContainer>
    </AppShell>
  );
}
