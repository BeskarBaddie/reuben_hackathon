import { useNavigate, useParams } from 'react-router';
import { Play, FileText, Lightbulb, Pencil, ArrowLeft, Droplets, Sprout, Calendar, MapPin } from 'lucide-react';
import { AppShell, PageContainer } from './AppShell';
import { MapPanel } from './MapPanel';
import { RiskBadge } from './shared/RiskBadge';
import { StatusBadge } from './shared/StatusBadge';
import { EmptyState, LoadingState } from './shared/EmptyState';
import { mockFarms, mockAnalyses } from '../mockData';

const irrigationLabel: Record<string, string> = {
  none: 'None',
  rainfed: 'Rainfed',
  partial: 'Partial',
  full: 'Full',
};

export function FarmDetail() {
  const navigate = useNavigate();
  const { farmId } = useParams<{ farmId: string }>();
  const farm = mockFarms.find(f => f.farm_id === farmId);

  if (!farm) {
    return (
      <AppShell breadcrumb={[{ label: 'Farms', href: '/farms' }, { label: 'Not Found' }]}>
        <PageContainer>
          <EmptyState
            icon={Sprout}
            title="Farm not found"
            description={`No farm with ID ${farmId} exists.`}
            action={
              <button onClick={() => navigate('/farms')} className="text-sm text-accent hover:underline">
                Back to farms
              </button>
            }
          />
        </PageContainer>
      </AppShell>
    );
  }

  const analysis = farm.latest_analysis_id ? mockAnalyses[farm.latest_analysis_id] : undefined;

  return (
    <AppShell
      breadcrumb={[{ label: 'Farms', href: '/farms' }, { label: farm.name }]}
      actions={
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate(`/farms/${farmId}/edit`)}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-border text-foreground bg-background rounded-md text-sm hover:bg-muted transition-colors"
          >
            <Pencil className="w-3.5 h-3.5" />
            Edit
          </button>
          <button
            onClick={() => navigate(`/farms/${farmId}`)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm hover:opacity-90 transition-opacity"
          >
            <Play className="w-3.5 h-3.5" />
            Run Analysis
          </button>
        </div>
      }
    >
      <PageContainer>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Left column: profile + map */}
          <div className="lg:col-span-1 space-y-4">
            {/* Farm profile */}
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="px-4 py-3 border-b border-border">
                <h3 className="text-sm font-medium text-foreground">Farm Profile</h3>
              </div>
              <div className="p-4 space-y-3">
                <ProfileRow icon={<Sprout className="w-3.5 h-3.5" />} label="Crop" value={farm.crop} />
                <ProfileRow icon={<Droplets className="w-3.5 h-3.5" />} label="Irrigation" value={irrigationLabel[farm.irrigation_type]} />
                <ProfileRow icon={<Calendar className="w-3.5 h-3.5" />} label="Planting Date"
                  value={new Date(farm.planting_date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })} mono />
                <ProfileRow icon={<MapPin className="w-3.5 h-3.5" />} label="Area"
                  value={`${farm.area_hectares} ha`} mono />
                <div className="pt-1">
                  <p className="text-xs text-muted-foreground mb-1 uppercase tracking-wide"
                    style={{ fontFamily: 'var(--font-mono)', fontSize: '10px' }}>
                    Latest Risk
                  </p>
                  {farm.latest_risk
                    ? <RiskBadge level={farm.latest_risk} size="md" showDot />
                    : <span className="text-xs text-muted-foreground">No analysis yet</span>}
                </div>
              </div>
            </div>

            {/* Map */}
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="px-4 py-3 border-b border-border">
                <h3 className="text-sm font-medium text-foreground">Boundary</h3>
              </div>
              <div className="p-3">
                <MapPanel boundary={farm.boundary} readonly height={220} />
              </div>
            </div>
          </div>

          {/* Right column: notes + analysis */}
          <div className="lg:col-span-2 space-y-4">
            {/* Farmer notes */}
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="px-4 py-3 border-b border-border">
                <h3 className="text-sm font-medium text-foreground">Field Notes</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Observations recorded by the farmer</p>
              </div>
              <div className="p-4">
                {farm.notes ? (
                  <p className="text-sm text-foreground leading-relaxed whitespace-pre-line">
                    {farm.notes}
                  </p>
                ) : (
                  <p className="text-sm text-muted-foreground italic">No notes recorded for this farm.</p>
                )}
              </div>
            </div>

            {/* Analysis status */}
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                <div>
                  <h3 className="text-sm font-medium text-foreground">Latest Analysis</h3>
                  {analysis && (
                    <p className="text-xs text-muted-foreground mt-0.5"
                      style={{ fontFamily: 'var(--font-mono)' }}>
                      ID: {analysis.analysis_id} · {new Date(analysis.created_at).toLocaleDateString('en-GB', {
                        day: '2-digit', month: 'short', year: 'numeric',
                      })}
                    </p>
                  )}
                </div>
                {analysis && <StatusBadge status={analysis.status} />}
              </div>

              {!analysis ? (
                <div className="px-4 py-8 text-center">
                  <p className="text-sm text-muted-foreground mb-3">No analysis has been run for this farm yet.</p>
                  <button
                    className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm mx-auto hover:opacity-90"
                  >
                    <Play className="w-4 h-4" />
                    Run Analysis
                  </button>
                </div>
              ) : (
                <div className="p-4">
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    {[
                      { label: 'Drought', score: analysis.drought_score, level: analysis.drought_level },
                      { label: 'Flood', score: analysis.flood_score, level: analysis.flood_level },
                      { label: 'Heat Stress', score: analysis.heat_score, level: analysis.heat_level },
                    ].map(r => (
                      <div key={r.label} className="border border-border rounded-md p-3 text-center">
                        <p className="text-xs text-muted-foreground mb-1">{r.label}</p>
                        <p className="text-lg font-semibold text-foreground mb-1"
                          style={{ fontFamily: 'var(--font-mono)' }}>
                          {(r.score * 100).toFixed(0)}
                        </p>
                        <RiskBadge level={r.level} />
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-md bg-muted/40 border border-border mb-4">
                    <span className="text-sm font-medium text-foreground">Overall Risk Level</span>
                    <RiskBadge level={analysis.overall_risk_level} size="md" showDot />
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => navigate(`/analyses/${analysis.analysis_id}`)}
                      className="flex items-center gap-1.5 px-3 py-1.5 border border-border text-foreground bg-background rounded-md text-sm hover:bg-muted transition-colors"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      View Full Report
                    </button>
                    <button
                      onClick={() => navigate(`/analyses/${analysis.analysis_id}/recommendations`)}
                      className="flex items-center gap-1.5 px-3 py-1.5 border border-border text-foreground bg-background rounded-md text-sm hover:bg-muted transition-colors"
                    >
                      <Lightbulb className="w-3.5 h-3.5 text-[#D97706]" />
                      Generate Recommendations
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </PageContainer>
    </AppShell>
  );
}

function ProfileRow({
  icon,
  label,
  value,
  mono,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  mono?: boolean;
}) {
  return (
    <div className="flex items-start gap-2">
      <span className="text-muted-foreground mt-0.5 flex-shrink-0">{icon}</span>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm text-foreground" style={{ fontFamily: mono ? 'var(--font-mono)' : undefined }}>
          {value}
        </p>
      </div>
    </div>
  );
}
