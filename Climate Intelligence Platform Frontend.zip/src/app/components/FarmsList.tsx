import { useNavigate } from 'react-router';
import { Plus, Eye, Play, Pencil, Sprout, MapPin } from 'lucide-react';
import { AppShell, PageContainer } from './AppShell';
import { RiskBadge } from './shared/RiskBadge';
import { EmptyState } from './shared/EmptyState';
import { mockFarms } from '../mockData';
import type { Farm } from '../types';

const irrigationLabel: Record<string, string> = {
  none: 'None',
  rainfed: 'Rainfed',
  partial: 'Partial',
  full: 'Full',
};

export function FarmsList() {
  const navigate = useNavigate();

  return (
    <AppShell
      breadcrumb={[{ label: 'Farms' }]}
      actions={
        <button
          onClick={() => navigate('/farms/new')}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm hover:opacity-90 transition-opacity"
        >
          <Plus className="w-3.5 h-3.5" />
          Add Farm
        </button>
      }
    >
      <PageContainer>
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          {mockFarms.length === 0 ? (
            <EmptyState
              icon={Sprout}
              title="No farms registered"
              description="Register your first farm to start running climate and satellite analyses."
              action={
                <button
                  onClick={() => navigate('/farms/new')}
                  className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm hover:opacity-90"
                >
                  <Plus className="w-4 h-4" />
                  Add Farm
                </button>
              }
            />
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/40">
                      {['Farm Name', 'Crop', 'Area (ha)', 'Irrigation', 'Planting Date', 'Latest Risk', 'Last Updated', ''].map((h) => (
                        <th key={h} className="text-left px-4 py-2.5 text-xs font-medium text-muted-foreground whitespace-nowrap"
                          style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {mockFarms.map((farm) => (
                      <FarmRow key={farm.farm_id} farm={farm} onNavigate={navigate} />
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="px-4 py-2.5 border-t border-border bg-muted/20">
                <p className="text-xs text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
                  {mockFarms.length} farm{mockFarms.length !== 1 ? 's' : ''} registered
                </p>
              </div>
            </>
          )}
        </div>
      </PageContainer>
    </AppShell>
  );
}

function FarmRow({ farm, onNavigate }: { farm: Farm; onNavigate: (path: string) => void }) {
  return (
    <tr
      className="border-b border-border last:border-0 hover:bg-muted/30 cursor-pointer transition-colors"
      onClick={() => onNavigate(`/farms/${farm.farm_id}`)}
    >
      <td className="px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-7 h-7 rounded-md bg-[#E8EDE6] flex-shrink-0">
            <Sprout className="w-3.5 h-3.5 text-accent" />
          </div>
          <div>
            <p className="font-medium text-foreground">{farm.name}</p>
            <p className="text-xs text-muted-foreground flex items-center gap-0.5">
              <MapPin className="w-2.5 h-2.5" />
              {farm.boundary ? 'Boundary mapped' : 'No boundary'}
            </p>
          </div>
        </div>
      </td>
      <td className="px-4 py-3 text-muted-foreground">{farm.crop}</td>
      <td className="px-4 py-3 text-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
        {farm.area_hectares.toFixed(1)}
      </td>
      <td className="px-4 py-3">
        <span className="px-2 py-0.5 bg-muted rounded text-xs text-muted-foreground">
          {irrigationLabel[farm.irrigation_type]}
        </span>
      </td>
      <td className="px-4 py-3 text-muted-foreground text-xs" style={{ fontFamily: 'var(--font-mono)' }}>
        {new Date(farm.planting_date).toLocaleDateString('en-GB', {
          day: '2-digit', month: 'short', year: 'numeric'
        })}
      </td>
      <td className="px-4 py-3">
        {farm.latest_risk
          ? <RiskBadge level={farm.latest_risk} showDot />
          : <span className="text-xs text-muted-foreground">No analysis</span>}
      </td>
      <td className="px-4 py-3 text-xs text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
        {new Date(farm.last_updated).toLocaleDateString('en-GB', {
          day: '2-digit', month: 'short'
        })}
      </td>
      <td className="px-4 py-3">
        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
          <button
            title="View farm"
            onClick={() => onNavigate(`/farms/${farm.farm_id}`)}
            className="p-1.5 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
          >
            <Eye className="w-3.5 h-3.5" />
          </button>
          <button
            title="Run analysis"
            onClick={() => onNavigate(`/farms/${farm.farm_id}`)}
            className="p-1.5 rounded-md hover:bg-[#D8F3DC] text-muted-foreground hover:text-accent transition-colors"
          >
            <Play className="w-3.5 h-3.5" />
          </button>
          <button
            title="Edit farm"
            onClick={() => onNavigate(`/farms/${farm.farm_id}/edit`)}
            className="p-1.5 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
          >
            <Pencil className="w-3.5 h-3.5" />
          </button>
        </div>
      </td>
    </tr>
  );
}
