import type { AnalysisStatus, RecommendationProvider } from '../../types';

interface StatusBadgeProps {
  status: AnalysisStatus;
}

const statusConfig: Record<AnalysisStatus, { label: string; className: string; dot: string }> = {
  pending: {
    label: 'Pending',
    className: 'bg-muted text-muted-foreground border border-border',
    dot: 'bg-muted-foreground',
  },
  running: {
    label: 'Running',
    className: 'bg-[#DBEAFE] text-[#1E40AF] border border-[#3B82F6]/20',
    dot: 'bg-[#3B82F6] animate-pulse',
  },
  complete: {
    label: 'Complete',
    className: 'bg-[#D8F3DC] text-[#1B4332] border border-[#40916C]/20',
    dot: 'bg-[#2D6A4F]',
  },
  failed: {
    label: 'Failed',
    className: 'bg-[#FEE2E2] text-[#991B1B] border border-[#DC2626]/20',
    dot: 'bg-[#DC2626]',
  },
};

export function StatusBadge({ status }: StatusBadgeProps) {
  const config = statusConfig[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium ${config.className}`}
      style={{ fontFamily: 'var(--font-mono)' }}
    >
      <span className={`inline-block w-1.5 h-1.5 rounded-full ${config.dot}`} />
      {config.label}
    </span>
  );
}

interface ProviderBadgeProps {
  provider: RecommendationProvider;
}

const providerConfig: Record<RecommendationProvider, { label: string; className: string }> = {
  deterministic: {
    label: 'Deterministic',
    className: 'bg-[#E8EDE6] text-[#1B4332] border border-[#40916C]/20',
  },
  openai: {
    label: 'OpenAI',
    className: 'bg-[#EDE9FE] text-[#5B21B6] border border-[#7C3AED]/20',
  },
  ollama: {
    label: 'Ollama',
    className: 'bg-[#DBEAFE] text-[#1E40AF] border border-[#3B82F6]/20',
  },
  fallback: {
    label: 'Fallback',
    className: 'bg-muted text-muted-foreground border border-border',
  },
};

export function ProviderBadge({ provider }: ProviderBadgeProps) {
  const config = providerConfig[provider];
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${config.className}`}
      style={{ fontFamily: 'var(--font-mono)' }}
    >
      {config.label}
    </span>
  );
}
