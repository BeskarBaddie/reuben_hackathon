import type { RiskLevel } from '../../types';

interface RiskBadgeProps {
  level: RiskLevel;
  size?: 'sm' | 'md';
  showDot?: boolean;
}

const riskConfig: Record<RiskLevel, { label: string; className: string }> = {
  low: {
    label: 'Low',
    className: 'bg-[#D8F3DC] text-[#1B4332] border border-[#40916C]/20',
  },
  medium: {
    label: 'Medium',
    className: 'bg-[#FEF3C7] text-[#92400E] border border-[#D97706]/20',
  },
  high: {
    label: 'High',
    className: 'bg-[#FEE2E2] text-[#991B1B] border border-[#DC2626]/20',
  },
  critical: {
    label: 'Critical',
    className: 'bg-[#FCA5A5] text-[#7F1D1D] border border-[#DC2626]/30',
  },
  unknown: {
    label: 'Unknown',
    className: 'bg-muted text-muted-foreground border border-border',
  },
};

export function RiskBadge({ level, size = 'sm', showDot = false }: RiskBadgeProps) {
  const config = riskConfig[level] ?? riskConfig.unknown;
  const sizeClass = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-3 py-1 text-sm';
  const dotColors: Record<RiskLevel, string> = {
    low: 'bg-[#2D6A4F]',
    medium: 'bg-[#D97706]',
    high: 'bg-[#DC2626]',
    critical: 'bg-[#7F1D1D]',
    unknown: 'bg-muted-foreground',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded font-medium ${config.className} ${sizeClass}`}
      style={{ fontFamily: 'var(--font-mono)' }}
    >
      {showDot && (
        <span className={`inline-block w-1.5 h-1.5 rounded-full ${dotColors[level]}`} />
      )}
      {config.label}
    </span>
  );
}
