interface MetricCardProps {
  label: string;
  value: string | number;
  unit?: string;
  subtext?: string;
  status?: 'normal' | 'warning' | 'alert' | 'good';
  mono?: boolean;
}

const statusColors = {
  normal: '',
  good: 'text-[#2D6A4F]',
  warning: 'text-[#D97706]',
  alert: 'text-[#DC2626]',
};

export function MetricCard({ label, value, unit, subtext, status = 'normal', mono = false }: MetricCardProps) {
  return (
    <div className="bg-card border border-border rounded-lg p-4 flex flex-col gap-1">
      <span className="text-xs text-muted-foreground uppercase tracking-wide"
        style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.06em' }}>
        {label}
      </span>
      <div className={`flex items-baseline gap-1 ${statusColors[status]}`}>
        <span className="text-2xl font-semibold"
          style={{ fontFamily: mono ? 'var(--font-mono)' : 'inherit' }}>
          {value}
        </span>
        {unit && <span className="text-sm text-muted-foreground">{unit}</span>}
      </div>
      {subtext && <span className="text-xs text-muted-foreground">{subtext}</span>}
    </div>
  );
}

interface SummaryCardProps {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  color?: string;
}

export function SummaryCard({ label, value, icon, color = 'bg-muted' }: SummaryCardProps) {
  return (
    <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-4">
      <div className={`flex items-center justify-center w-10 h-10 rounded-lg flex-shrink-0 ${color}`}>
        {icon}
      </div>
      <div>
        <p className="text-xs text-muted-foreground"
          style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.05em', textTransform: 'uppercase' }}>
          {label}
        </p>
        <p className="text-xl font-semibold text-foreground">{value}</p>
      </div>
    </div>
  );
}
