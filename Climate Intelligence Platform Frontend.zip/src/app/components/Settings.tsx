import { useState } from 'react';
import { Save, CheckCircle2, XCircle, RefreshCw } from 'lucide-react';
import { AppShell, PageContainer } from './AppShell';

type RecommendationProvider = 'deterministic' | 'ollama' | 'openai';
type MapProvider = 'openstreetmap' | 'mapbox' | 'google';

interface SettingsState {
  backendUrl: string;
  mapProvider: MapProvider;
  recommendationProvider: RecommendationProvider;
  ollamaBaseUrl: string;
  ollamaModel: string;
  openaiApiKey: string;
  openaiModel: string;
}

function ConnectionStatus({ connected, label }: { connected: boolean; label: string }) {
  return (
    <div className="flex items-center gap-1.5 text-xs">
      {connected
        ? <CheckCircle2 className="w-3.5 h-3.5 text-[#2D6A4F]" />
        : <XCircle className="w-3.5 h-3.5 text-[#DC2626]" />}
      <span className={connected ? 'text-[#2D6A4F]' : 'text-[#DC2626]'}
        style={{ fontFamily: 'var(--font-mono)' }}>
        {connected ? `Connected · ${label}` : `Not reachable · ${label}`}
      </span>
    </div>
  );
}

export function Settings() {
  const [settings, setSettings] = useState<SettingsState>({
    backendUrl: 'http://localhost:8000',
    mapProvider: 'openstreetmap',
    recommendationProvider: 'deterministic',
    ollamaBaseUrl: 'http://localhost:11434',
    ollamaModel: 'llama3.2',
    openaiApiKey: '',
    openaiModel: 'gpt-4o',
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [testingOllama, setTestingOllama] = useState(false);
  const [ollamaStatus, setOllamaStatus] = useState<'unknown' | 'ok' | 'fail'>('unknown');
  const [backendStatus] = useState<boolean>(true);

  function update<K extends keyof SettingsState>(key: K, value: SettingsState[K]) {
    setSettings(prev => ({ ...prev, [key]: value }));
    setSaved(false);
  }

  async function handleSave() {
    setSaving(true);
    await new Promise(r => setTimeout(r, 600));
    setSaving(false);
    setSaved(true);
  }

  async function testOllama() {
    setTestingOllama(true);
    await new Promise(r => setTimeout(r, 1000));
    setOllamaStatus(settings.ollamaBaseUrl.includes('localhost') ? 'ok' : 'fail');
    setTestingOllama(false);
  }

  return (
    <AppShell breadcrumb={[{ label: 'Settings' }]}>
      <PageContainer>
        <div className="max-w-xl space-y-5">
          {/* Backend connection */}
          <Section title="Backend Connection" description="ClimateIQ API server endpoint">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1"
                style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                API Base URL
              </label>
              <input
                type="url"
                value={settings.backendUrl}
                onChange={e => update('backendUrl', e.target.value)}
                className="w-full px-3 py-2 rounded-md text-sm bg-input-background border border-border text-foreground outline-none focus:ring-2 focus:ring-ring transition-shadow"
                style={{ fontFamily: 'var(--font-mono)' }}
              />
              <div className="mt-2">
                <ConnectionStatus connected={backendStatus} label={settings.backendUrl} />
              </div>
              <div className="mt-2 p-3 bg-muted/40 rounded-md border border-border">
                <p className="text-xs text-muted-foreground mb-1 font-medium">REST Endpoints</p>
                {[
                  'POST /api/v1/farms',
                  'POST /api/v1/farms/{farm_id}/analyses',
                  'GET /api/v1/analyses/{analysis_id}',
                  'POST /api/v1/analyses/{analysis_id}/recommendations',
                  'GET /api/v1/analyses/{analysis_id}/recommendations',
                ].map(ep => (
                  <p key={ep} className="text-xs text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
                    {ep}
                  </p>
                ))}
              </div>
            </div>
          </Section>

          {/* Map provider */}
          <Section title="Map Provider" description="Tile source for the boundary drawing map">
            <RadioGroup
              name="mapProvider"
              value={settings.mapProvider}
              onChange={v => update('mapProvider', v as MapProvider)}
              options={[
                { value: 'openstreetmap', label: 'OpenStreetMap', description: 'Free, open-source tiles' },
                { value: 'mapbox', label: 'Mapbox', description: 'Requires Mapbox API token' },
                { value: 'google', label: 'Google Maps', description: 'Requires Google Maps API key' },
              ]}
            />
          </Section>

          {/* Recommendation provider */}
          <Section title="Recommendation Provider" description="How adaptation recommendations are generated">
            <RadioGroup
              name="recProvider"
              value={settings.recommendationProvider}
              onChange={v => update('recommendationProvider', v as RecommendationProvider)}
              options={[
                { value: 'deterministic', label: 'Deterministic', description: 'Rule-based, no external model required' },
                { value: 'ollama', label: 'Ollama (local LLM)', description: 'Run a local model via Ollama' },
                { value: 'openai', label: 'OpenAI', description: 'Use OpenAI API — requires API key' },
              ]}
            />
          </Section>

          {/* Ollama settings */}
          {settings.recommendationProvider === 'ollama' && (
            <Section title="Ollama Settings" description="Configure local Ollama server">
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1"
                    style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    Base URL
                  </label>
                  <input
                    type="url"
                    value={settings.ollamaBaseUrl}
                    onChange={e => update('ollamaBaseUrl', e.target.value)}
                    className="w-full px-3 py-2 rounded-md text-sm bg-input-background border border-border text-foreground outline-none focus:ring-2 focus:ring-ring"
                    style={{ fontFamily: 'var(--font-mono)' }}
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1"
                    style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    Model
                  </label>
                  <input
                    type="text"
                    value={settings.ollamaModel}
                    onChange={e => update('ollamaModel', e.target.value)}
                    placeholder="e.g. llama3.2, mistral, gemma2"
                    className="w-full px-3 py-2 rounded-md text-sm bg-input-background border border-border text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring"
                    style={{ fontFamily: 'var(--font-mono)' }}
                  />
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={testOllama}
                    disabled={testingOllama}
                    className="flex items-center gap-1.5 px-3 py-1.5 border border-border bg-background text-foreground rounded-md text-xs hover:bg-muted transition-colors disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3 h-3 ${testingOllama ? 'animate-spin' : ''}`} />
                    Test Connection
                  </button>
                  {ollamaStatus !== 'unknown' && (
                    <ConnectionStatus
                      connected={ollamaStatus === 'ok'}
                      label={settings.ollamaBaseUrl}
                    />
                  )}
                </div>
              </div>
            </Section>
          )}

          {/* OpenAI settings */}
          {settings.recommendationProvider === 'openai' && (
            <Section title="OpenAI Settings" description="Configure OpenAI API access">
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1"
                    style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    API Key
                  </label>
                  <input
                    type="password"
                    value={settings.openaiApiKey}
                    onChange={e => update('openaiApiKey', e.target.value)}
                    placeholder="sk-••••••••••••••••••••"
                    className="w-full px-3 py-2 rounded-md text-sm bg-input-background border border-border text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring"
                    style={{ fontFamily: 'var(--font-mono)' }}
                    autoComplete="off"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    API key is never displayed after saving. Store securely in your environment.
                  </p>
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1"
                    style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    Model
                  </label>
                  <select
                    value={settings.openaiModel}
                    onChange={e => update('openaiModel', e.target.value)}
                    className="w-full px-3 py-2 rounded-md text-sm bg-input-background border border-border text-foreground outline-none focus:ring-2 focus:ring-ring"
                    style={{ fontFamily: 'var(--font-mono)' }}
                  >
                    <option value="gpt-4o">gpt-4o</option>
                    <option value="gpt-4o-mini">gpt-4o-mini</option>
                    <option value="gpt-4-turbo">gpt-4-turbo</option>
                  </select>
                </div>
              </div>
            </Section>
          )}

          {/* Save button */}
          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:opacity-90 disabled:opacity-50 transition-opacity"
            >
              <Save className="w-4 h-4" />
              {saving ? 'Saving…' : 'Save Settings'}
            </button>
            {saved && (
              <div className="flex items-center gap-1.5 text-xs text-[#2D6A4F]">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Settings saved
              </div>
            )}
          </div>
        </div>
      </PageContainer>
    </AppShell>
  );
}

function Section({ title, description, children }: { title: string; description: string; children: React.ReactNode }) {
  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      <div className="px-4 py-3 border-b border-border">
        <h3 className="text-sm font-medium text-foreground">{title}</h3>
        <p className="text-xs text-muted-foreground mt-0.5">{description}</p>
      </div>
      <div className="p-4">{children}</div>
    </div>
  );
}

function RadioGroup<T extends string>({
  name,
  value,
  onChange,
  options,
}: {
  name: string;
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string; description: string }[];
}) {
  return (
    <div className="space-y-2">
      {options.map(opt => (
        <label
          key={opt.value}
          className={`flex items-start gap-3 p-3 rounded-md border cursor-pointer transition-colors ${
            value === opt.value
              ? 'border-accent bg-[#E8EDE6]'
              : 'border-border hover:bg-muted'
          }`}
        >
          <input
            type="radio"
            name={name}
            value={opt.value}
            checked={value === opt.value}
            onChange={() => onChange(opt.value)}
            className="mt-0.5 accent-accent"
          />
          <div>
            <p className="text-sm font-medium text-foreground">{opt.label}</p>
            <p className="text-xs text-muted-foreground">{opt.description}</p>
          </div>
        </label>
      ))}
    </div>
  );
}
