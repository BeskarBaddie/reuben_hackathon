import { useNavigate } from 'react-router';
import { MapPin } from 'lucide-react';
import { AppShell, PageContainer } from './AppShell';

export function NotFound() {
  const navigate = useNavigate();
  return (
    <AppShell title="Page Not Found">
      <PageContainer>
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <div className="flex items-center justify-center w-14 h-14 rounded-xl bg-muted mb-5">
            <MapPin className="w-7 h-7 text-muted-foreground" />
          </div>
          <h2 className="text-foreground mb-2">Page not found</h2>
          <p className="text-sm text-muted-foreground max-w-xs mb-6">
            The page you're looking for doesn't exist or has been moved.
          </p>
          <button
            onClick={() => navigate('/')}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm hover:opacity-90"
          >
            Back to Dashboard
          </button>
        </div>
      </PageContainer>
    </AppShell>
  );
}
