import { useNavigate } from 'react-router';
import {
  Sprout, BarChart2, AlertTriangle, Lightbulb,
  Plus, Play, ArrowRight, Activity, TrendingUp,
} from 'lucide-react';
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
} from 'recharts';
import { AppShell, PageContainer } from './AppShell';
import { SummaryCard } from './shared/MetricCard';
import { RiskBadge } from './shared/RiskBadge';
import { StatusBadge } from './shared/StatusBadge';
import { mockFarms, mockAnalyses } from '../mockData';

const RISK_COLORS: Record<string, string> = {
  low: '#2D6A4F',
  medium: '#D97706',
  high: '#DC2626',
  critical: '#7F1D1D',
  unknown: '#A8B5A0',
};

export function Dashboard() {
  const navigate = useNavigate();

  const totalFarms = mockFarms.length;
  const analyses = Object.values(mockAnalyses);
  const latestAnalysis = analyses.sort(
    (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  )[0];
  const highRiskCount = mockFarms.filter(
    f => f.latest_risk === 'high' || f.latest_risk === 'critical'
  ).length;

  // Risk distribution for pie chart
  const riskGroups = mockFarms.reduce<Record<string, number>>((acc, f) => {
    const level = f.latest_risk ?? 'unknown';
    acc[level] = (acc[level] ?? 0) + 1;
    return acc;
  }, {});
  const riskPieData = Object.entries(riskGroups).map(([level, count]) => ({
    name: level.charAt(0).toUpperCase() + level.slice(1),
    value: count,
    color: RISK_COLORS[level],
  }));

  // Risk scores bar chart data
  const riskBarData = mockFarms
    .filter(f => f.latest_analysis_id && mockAnalyses[f.latest_analysis_id])
    .map(f => {
      const a = mockAnalyses[f.latest_analysis_id!];
      return {
        name: f.name.split(' ')[0],
        drought: Math.round(a.drought_score * 100),
        flood: Math.round(a.flood_score * 100),
        heat: Math.round(a.heat_score * 100),
      };
    });

  return (
    <AppShell
      title="Dashboard"
      actions={
        <button
          onClick={() => navigate('/farms/new')}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm hover:opacity-90 transition-opacity"
        >
          <Plus className="w-3.5 h-3.5" />
          Add Farm
        </button>
      }
    >
      <PageContainer>
        {/* Summary strip */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
          <SummaryCard label="Total Farms" value={totalFarms}
            icon={<Sprout className="w-5 h-5 text-accent" />}
            color="bg-[#E8EDE6]" />
          <SummaryCard
            label="Latest Analysis"
            value={latestAnalysis?.status === 'complete' ? 'Complete' : 'Pending'}
            icon={<Activity className="w-5 h-5 text-[#3B82F6]" />}
            color="bg-[#DBEAFE]" />
          <SummaryCard label="High Risk Farms" value={highRiskCount}
            icon={<AlertTriangle className="w-5 h-5 text-[#DC2626]" />}
            color="bg-[#FEE2E2]" />
          <SummaryCard label="Recommendations" value={2}
            icon={<Lightbulb className="w-5 h-5 text-[#D97706]" />}
            color="bg-[#FEF3C7]" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
          {/* Farm activity table */}
          <div className="lg:col-span-2 bg-card border border-border rounded-lg overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <h3 className="text-sm font-medium text-foreground">Farm Overview</h3>
              <button onClick={() => navigate('/farms')}
                className="flex items-center gap-1 text-xs text-accent hover:underline">
                View all <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/30">
                    {['Farm', 'Crop', 'Area', 'Risk', 'Updated'].map(h => (
                      <th key={h}
                        className="text-left px-4 py-2.5 text-xs font-medium text-muted-foreground whitespace-nowrap"
                        style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                        {h}
                      </th>
                    ))}
                    <th className="px-4 py-2.5" />
                  </tr>
                </thead>
                <tbody>
                  {mockFarms.map(farm => (
                    <tr
                      key={farm.farm_id}
                      onClick={() => navigate(`/farms/${farm.farm_id}`)}
                      className="border-b border-border last:border-0 hover:bg-muted/20 cursor-pointer transition-colors"
                    >
                      <td className="px-4 py-3">
                        <p className="font-medium text-foreground truncate max-w-[140px]">{farm.name}</p>
                        <p className="text-xs text-muted-foreground">{farm.area_hectares} ha</p>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{farm.crop}</td>
                      <td className="px-4 py-3 text-sm" style={{ fontFamily: 'var(--font-mono)' }}>
                        {farm.area_hectares} ha
                      </td>
                      <td className="px-4 py-3">
                        {farm.latest_risk
                          ? <RiskBadge level={farm.latest_risk} showDot />
                          : <span className="text-xs text-muted-foreground">—</span>}
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground"
                        style={{ fontFamily: 'var(--font-mono)' }}>
                        {new Date(farm.last_updated).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2" onClick={e => e.stopPropagation()}>
                          <button
                            onClick={() => navigate(`/farms/${farm.farm_id}`)}
                            className="text-xs text-accent hover:underline whitespace-nowrap">
                            View →
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Risk distribution + actions */}
          <div className="space-y-3">
            {/* Pie chart */}
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="px-4 py-3 border-b border-border">
                <h3 className="text-sm font-medium text-foreground">Risk Distribution</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Across all registered farms</p>
              </div>
              <div className="px-4 py-3">
                <div className="h-[140px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={riskPieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={60}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {riskPieData.map((entry, i) => (
                          <Cell key={i} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        content={({ active, payload }) =>
                          active && payload?.length ? (
                            <div className="bg-card border border-border rounded px-2 py-1 text-xs shadow">
                              <p className="font-medium">{payload[0].name}: {payload[0].value} farm{payload[0].value !== 1 ? 's' : ''}</p>
                            </div>
                          ) : null
                        }
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex flex-wrap gap-x-3 gap-y-1 justify-center">
                  {riskPieData.map(({ name, color, value }) => (
                    <div key={name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: color }} />
                      {name} ({value})
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick actions */}
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="px-4 py-3 border-b border-border">
                <h3 className="text-sm font-medium text-foreground">Quick Actions</h3>
              </div>
              <div className="p-3 space-y-1.5">
                <button
                  onClick={() => navigate('/farms/new')}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-md text-sm bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
                >
                  <Plus className="w-4 h-4" /> Add Farm
                </button>
                <button
                  onClick={() => navigate(`/farms/${mockFarms[0].farm_id}`)}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-md text-sm border border-border bg-background text-foreground hover:bg-muted transition-colors"
                >
                  <Play className="w-4 h-4 text-accent" /> Run Analysis
                </button>
                <button
                  onClick={() => navigate(`/analyses/ana-001/recommendations`)}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-md text-sm border border-border bg-background text-foreground hover:bg-muted transition-colors"
                >
                  <Lightbulb className="w-4 h-4 text-[#D97706]" /> View Recommendations
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Risk scores bar chart */}
        {riskBarData.length > 0 && (
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <h3 className="text-sm font-medium text-foreground">Risk Scores by Farm</h3>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                {[
                  { label: 'Drought', color: '#DC2626' },
                  { label: 'Flood', color: '#3B82F6' },
                  { label: 'Heat', color: '#D97706' },
                ].map(({ label, color }) => (
                  <span key={label} className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-sm" style={{ background: color }} />
                    {label}
                  </span>
                ))}
              </div>
            </div>
            <div className="px-4 py-4 h-[160px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={riskBarData} barSize={12} barGap={2}
                  margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <CartesianGrid vertical={false} stroke="rgba(0,0,0,0.05)" />
                  <XAxis dataKey="name"
                    tick={{ fontSize: 11, fill: '#5C6358', fontFamily: 'var(--font-mono)' }}
                    axisLine={false} tickLine={false} />
                  <YAxis domain={[0, 100]}
                    tick={{ fontSize: 10, fill: '#5C6358', fontFamily: 'var(--font-mono)' }}
                    axisLine={false} tickLine={false} />
                  <Tooltip
                    content={({ active, payload, label }) =>
                      active && payload?.length ? (
                        <div className="bg-card border border-border rounded-md px-3 py-2 shadow text-xs">
                          <p className="font-medium text-foreground mb-1">{label}</p>
                          {payload.map((p: any, i: number) => (
                            <p key={i} style={{ color: p.fill, fontFamily: 'var(--font-mono)' }}>
                              {p.name}: {p.value}
                            </p>
                          ))}
                        </div>
                      ) : null
                    }
                  />
                  <Bar dataKey="drought" fill="#DC2626" radius={[2, 2, 0, 0]} />
                  <Bar dataKey="flood" fill="#3B82F6" radius={[2, 2, 0, 0]} />
                  <Bar dataKey="heat" fill="#D97706" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </PageContainer>
    </AppShell>
  );
}
