import { useRef, useEffect, useState } from 'react';
import { MapPin, Trash2, Maximize2 } from 'lucide-react';
import type { GeoJSONPolygon } from '../types';

interface MapPanelProps {
  boundary: GeoJSONPolygon | null;
  onBoundaryChange?: (boundary: GeoJSONPolygon | null) => void;
  readonly?: boolean;
  height?: number;
}

export function MapPanel({ boundary, onBoundaryChange, readonly = false, height = 300 }: MapPanelProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [points, setPoints] = useState<{ x: number; y: number }[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hoveredPoint, setHoveredPoint] = useState<number | null>(null);

  const CANVAS_W = 600;
  const CANVAS_H = height;

  // Grid and map background drawing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = CANVAS_W * dpr;
    canvas.height = CANVAS_H * dpr;
    ctx.scale(dpr, dpr);
    canvas.style.width = `${CANVAS_W}px`;
    canvas.style.height = `${CANVAS_H}px`;

    drawMap(ctx, CANVAS_W, CANVAS_H, points, hoveredPoint);
  }, [points, hoveredPoint, CANVAS_H]);

  // If readonly and boundary provided, render it
  useEffect(() => {
    if (readonly && boundary) {
      const coords = boundary.coordinates[0];
      // Normalize coords to canvas space
      const lngs = coords.map(c => c[0]);
      const lats = coords.map(c => c[1]);
      const minLng = Math.min(...lngs), maxLng = Math.max(...lngs);
      const minLat = Math.min(...lats), maxLat = Math.max(...lats);
      const pad = 40;
      const canvasPoints = coords.slice(0, -1).map(c => ({
        x: pad + ((c[0] - minLng) / (maxLng - minLng || 1)) * (CANVAS_W - pad * 2),
        y: CANVAS_H - pad - ((c[1] - minLat) / (maxLat - minLat || 1)) * (CANVAS_H - pad * 2),
      }));
      setPoints(canvasPoints);
    }
  }, [boundary, readonly, CANVAS_H, CANVAS_W]);

  function handleClick(e: React.MouseEvent<HTMLCanvasElement>) {
    if (readonly) return;
    const rect = canvasRef.current!.getBoundingClientRect();
    const scaleX = CANVAS_W / rect.width;
    const scaleY = CANVAS_H / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    if (points.length >= 3) {
      const firstPoint = points[0];
      const dist = Math.hypot(x - firstPoint.x, y - firstPoint.y);
      if (dist < 20) {
        // Close polygon
        emitBoundary(points);
        return;
      }
    }

    const newPoints = [...points, { x, y }];
    setPoints(newPoints);
    setIsDrawing(true);
  }

  function emitBoundary(pts: { x: number; y: number }[]) {
    if (!onBoundaryChange) return;
    // Convert canvas coords to mock geo coords
    const coords = pts.map(p => [
      32.55 + (p.x / CANVAS_W) * 0.15,
      0.28 + ((CANVAS_H - p.y) / CANVAS_H) * 0.15,
    ]);
    coords.push(coords[0]);
    onBoundaryChange({ type: 'Polygon', coordinates: [coords] });
  }

  function handleClear() {
    setPoints([]);
    setIsDrawing(false);
    onBoundaryChange?.(null);
  }

  function handleFit() {
    if (points.length < 3) return;
    // Centering animation — just redraw
    setPoints([...points]);
  }

  const hasBoundary = points.length >= 3;

  return (
    <div className="flex flex-col">
      <div className="relative rounded-lg overflow-hidden border border-border bg-[#E8EDE6]">
        <canvas
          ref={canvasRef}
          className="w-full cursor-crosshair"
          style={{ height: `${height}px`, cursor: readonly ? 'default' : 'crosshair' }}
          onClick={handleClick}
          onMouseMove={(e) => {
            if (readonly || points.length === 0) return;
            const rect = canvasRef.current!.getBoundingClientRect();
            const scaleX = CANVAS_W / rect.width;
            const scaleY = CANVAS_H / rect.height;
            const mx = (e.clientX - rect.left) * scaleX;
            const my = (e.clientY - rect.top) * scaleY;
            const idx = points.findIndex(p => Math.hypot(mx - p.x, my - p.y) < 16);
            setHoveredPoint(idx === -1 ? null : idx);
          }}
          onMouseLeave={() => setHoveredPoint(null)}
        />
        {!readonly && (
          <div className="absolute top-2 right-2 flex gap-1.5">
            <button
              onClick={handleFit}
              title="Fit boundary"
              className="p-1.5 bg-card/90 backdrop-blur-sm rounded-md border border-border text-muted-foreground hover:text-foreground transition-colors text-xs"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleClear}
              title="Clear boundary"
              className="p-1.5 bg-card/90 backdrop-blur-sm rounded-md border border-border text-muted-foreground hover:text-[#DC2626] transition-colors text-xs"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* Boundary status panel */}
      <div className={`mt-2 flex items-center gap-2 px-3 py-2 rounded-md text-xs border ${
        hasBoundary
          ? 'bg-[#D8F3DC] border-[#40916C]/20 text-[#1B4332]'
          : 'bg-muted border-border text-muted-foreground'
      }`}>
        <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
        {hasBoundary ? (
          <span>
            Boundary selected · <span style={{ fontFamily: 'var(--font-mono)' }}>{points.length} vertices</span>
            {' '}· Area estimated
          </span>
        ) : readonly ? (
          <span>No boundary mapped for this farm</span>
        ) : (
          <span>Click on the map to draw a boundary polygon. Click near the first point to close it.</span>
        )}
      </div>
    </div>
  );
}

function drawMap(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  points: { x: number; y: number }[],
  hoveredPoint: number | null
) {
  // Background — light terrain
  ctx.fillStyle = '#E8EDE6';
  ctx.fillRect(0, 0, w, h);

  // Grid lines
  ctx.strokeStyle = 'rgba(26, 28, 24, 0.06)';
  ctx.lineWidth = 1;
  const gridSize = 40;
  for (let x = 0; x <= w; x += gridSize) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 0; y <= h; y += gridSize) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }

  // Terrain patches (decorative)
  const patches = [
    { x: 80, y: 60, r: 50, color: 'rgba(64, 145, 108, 0.08)' },
    { x: 300, y: 120, r: 80, color: 'rgba(64, 145, 108, 0.06)' },
    { x: 480, y: 80, r: 45, color: 'rgba(64, 145, 108, 0.07)' },
    { x: 200, y: 200, r: 65, color: 'rgba(64, 145, 108, 0.05)' },
    { x: 420, y: 220, r: 70, color: 'rgba(64, 145, 108, 0.08)' },
  ];
  patches.forEach(p => {
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fillStyle = p.color;
    ctx.fill();
  });

  // "Road" lines
  ctx.strokeStyle = 'rgba(26, 28, 24, 0.08)';
  ctx.lineWidth = 2;
  ctx.setLineDash([]);
  ctx.beginPath();
  ctx.moveTo(0, h * 0.6);
  ctx.bezierCurveTo(w * 0.3, h * 0.58, w * 0.6, h * 0.62, w, h * 0.6);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(w * 0.4, 0);
  ctx.bezierCurveTo(w * 0.42, h * 0.4, w * 0.38, h * 0.6, w * 0.4, h);
  ctx.stroke();

  if (points.length === 0) {
    // Hint text
    ctx.fillStyle = 'rgba(92, 99, 88, 0.5)';
    ctx.font = '13px Inter, system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Click to place boundary points', w / 2, h / 2 - 8);
    ctx.font = '11px Inter, system-ui, sans-serif';
    ctx.fillText('Click near first point to close polygon', w / 2, h / 2 + 12);
    return;
  }

  // Draw filled polygon if closed (≥3 points)
  if (points.length >= 3) {
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
      ctx.lineTo(points[i].x, points[i].y);
    }
    ctx.closePath();
    ctx.fillStyle = 'rgba(45, 106, 79, 0.15)';
    ctx.fill();
    ctx.strokeStyle = '#2D6A4F';
    ctx.lineWidth = 2;
    ctx.setLineDash([]);
    ctx.stroke();
  } else {
    // Open path
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
      ctx.lineTo(points[i].x, points[i].y);
    }
    ctx.strokeStyle = '#2D6A4F';
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 4]);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Draw vertex points
  points.forEach((p, i) => {
    const isHovered = hoveredPoint === i;
    const isFirst = i === 0;
    ctx.beginPath();
    ctx.arc(p.x, p.y, isFirst ? 7 : 5, 0, Math.PI * 2);
    ctx.fillStyle = isFirst ? '#1B4332' : (isHovered ? '#40916C' : '#2D6A4F');
    ctx.fill();
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.stroke();
  });
}
