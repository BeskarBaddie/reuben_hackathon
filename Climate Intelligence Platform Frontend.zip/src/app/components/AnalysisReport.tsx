import { useNavigate, useParams } from 'react-router';
import { Lightbulb, TrendingDown, TrendingUp, Minus, BarChart2, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, Cell,
} from 'recharts';
import { AppShell, PageContainer } from './AppShell';
import { RiskBadge } from './shared/RiskBadge';
import { StatusBadge } from './shared/StatusBadge';
import { EmptyState } from './shared/EmptyState';
import { mockAnalyses, mockFarms } from '../mockData';
import type { RiskLevel } from '../types';

function AnomalyIndicator({ value, unit = '' }: { value: number; unit?: string }) {
  const positive = value > 0;
  const zero = value === 0;
  const Icon = zero ? Minus : positive ? TrendingUp : TrendingDown;
  const color = zero ? 'text-muted-foreground' : positive ? 'text-[#DC2626]' : 'text-[#2D6A4F]';
  return (
    <span className={`inline-flex items-center gap-0.5 text-sm font-medium ${color}`}
      style={{ fontFamily: 'var(--font-mono)' }}>
      <Icon className="w-3.5 h-3.5" />
      {positive ? '+' : ''}{value}{unit}
    </span>
  );
}

interface RiskRowProps {
  label: string;
  score: number;
  level: RiskLevel;
  evidenceItems: string[];
}

function RiskScoreCard({ label, score, level, evidenceItems }: RiskRowProps) {
  const pct = Math.round(score * 100);
  const barColor =
    level === 'high' || level === 'critical' ? '#DC2626' :
    level === 'medium' ? '#D97706' : '#2D6A4F';
  const bgColor =
    level === 'high' || level === 'critical' ? '#FEE2E2' :
    level === 'medium' ? '#FEF3C7' : '#D8F3DC';

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <span className="text-sm font-medium text-foreground">{label}</span>
        <div className="flex items-center gap-3">
          <span className="text-lg font-semibold" style={{ fontFamily: 'var(--font-mono)', color: barColor }}>
            {pct}
          </span>
          <RiskBadge level={level} showDot />
        </div>
      </div>
      {/* Score bar */}
      <div className="px-4 py-2" style={{ background: bgColor + '40' }}>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{ width: `${pct}%`, background: barColor }}
          />
        </div>
      </div>
      {/* Evidence */}
      <div className="px-4 py-3">
        <p className="text-xs text-muted-foreground uppercase mb-2"
          style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.06em', fontSize: '10px' }}>
          Evidence & Drivers
        </p>
        <ul className="space-y-1">
          {evidenceItems.map((e, i) => (
            <li key={i} className="text-xs text-foreground flex items-start gap-2">
              <span className="mt-1.5 w-1 h-1 rounded-full flex-shrink-0" style={{ background: barColor }} />
              {e}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function MetricTile({
  label, value, sub, status = 'normal',
}: {
  label: string; value: string; sub?: string; status?: 'normal' | 'good' | 'warning' | 'alert';
}) {
  const valueColor = {
    normal: 'text-foreground',
    good: 'text-[#2D6A4F]',
    warning: 'text-[#D97706]',
    alert: 'text-[#DC2626]',
  }[status];
  return (
    <div className="bg-card border border-border rounded-lg p-3">
      <p className="text-xs text-muted-foreground mb-1 uppercase"
        style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.05em', fontSize: '10px' }}>
        {label}
      </p>
      <p className={`text-base font-semibold ${valueColor}`} style={{ fontFamily: 'var(--font-mono)' }}>
        {value}
      </p>
      {sub && <p className="text-xs text-muted-foreground mt-0.5 capitalize">{sub}</p>}
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-md px-3 py-2 shadow-md text-xs">
      <p className="font-medium text-foreground mb-1">{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} style={{ color: p.color, fontFamily: 'var(--font-mono)' }}>
          {p.name}: {p.value}
        </p>
      ))}
    </div>
  );
};

export function AnalysisReport() {
  const navigate = useNavigate();
  const { analysisId } = useParams<{ analysisId: string }>();
  const analysis = analysisId ? mockAnalyses[analysisId] : undefined;
  const farm = analysis ? mockFarms.find(f => f.farm_id === analysis.farm_id) : undefined;

  if (!analysis) {
    return (
      <AppShell breadcrumb={[{ label: 'Analysis Report' }]}>
        <PageContainer>
          <EmptyState icon={BarChart2} title="Analysis not found"
            description={`No analysis with ID ${analysisId} exists.`} />
        </PageContainer>
      </AppShell>
    );
  }

  const rainfallChartData = [
    { name: 'Historical Avg', value: analysis.historical_rainfall_avg, fill: '#A8B5A0' },
    { name: 'This Season', value: analysis.rainfall_this_season,
      fill: analysis.rainfall_anomaly_percent < -15 ? '#DC2626' :
            analysis.rainfall_anomaly_percent < 0 ? '#D97706' : '#2D6A4F' },
  ];

  const radarData = [
    { metric: 'Drought', score: Math.round(analysis.drought_score * 100) },
    { metric: 'Flood', score: Math.round(analysis.flood_score * 100) },
    { metric: 'Heat', score: Math.round(analysis.heat_score * 100) },
    { metric: 'Water Stress', score: analysis.water_stress === 'severe' ? 80 :
      analysis.water_stress === 'moderate' ? 50 : 20 },
    { metric: 'NDVI Deficit', score: Math.round((1 - analysis.ndvi) * 100) },
  ];

  const droughtEvidence = analysis.evidence.slice(0, 2);
  const floodEvidence = [analysis.evidence[4] ?? analysis.evidence[0]];
  const heatEvidence = [analysis.evidence[2] ?? analysis.evidence[0]];

  return (
    <AppShell
      breadcrumb={[
        { label: 'Farms', href: '/farms' },
        ...(farm ? [{ label: farm.name, href: `/farms/${farm.farm_id}` }] : []),
        { label: 'Analysis Report' },
      ]}
      actions={
        <button
          onClick={() => navigate(`/analyses/${analysisId}/recommendations`)}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm hover:opacity-90 transition-opacity"
        >
          <Lightbulb className="w-3.5 h-3.5" />
          Generate Recommendations
        </button>
      }
    >
      <PageContainer>
        {/* Status bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-4 border-b border-border">
          <div className="flex flex-wrap items-center gap-3">
            <StatusBadge status={analysis.status} />
            <span className="text-xs text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
              {analysis.analysis_id}
            </span>
            <span className="text-xs text-muted-foreground">
              {new Date(analysis.created_at).toLocaleDateString('en-GB', {
                day: '2-digit', month: 'long', year: 'numeric',
              })}
            </span>
            {farm && (
              <span className="text-xs text-muted-foreground">
                · {farm.name} · {farm.crop}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Overall Risk</span>
            <RiskBadge level={analysis.overall_risk_level} size="md" showDot />
          </div>
        </div>

        {/* Climate signal */}
        <div className="bg-card border border-border rounded-lg px-4 py-3 mb-5">
          <p className="text-xs text-muted-foreground uppercase mb-1.5"
            style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.06em', fontSize: '10px' }}>
            Climate Signal Summary
          </p>
          <p className="text-sm text-foreground leading-relaxed">{analysis.climate_signal}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-5">
          {/* Left: metrics */}
          <div className="lg:col-span-2 space-y-4">
            {/* Satellite & vegetation */}
            <div>
              <SectionLabel>Satellite & Vegetation</SectionLabel>
              <div className="grid grid-cols-3 gap-3">
                <MetricTile label="NDVI" value={analysis.ndvi.toFixed(2)}
                  sub={`vegetation: ${analysis.vegetation_health}`}
                  status={analysis.ndvi > 0.6 ? 'good' : analysis.ndvi > 0.4 ? 'warning' : 'alert'} />
                <MetricTile label="Vegetation Health" value={analysis.vegetation_health}
                  status={analysis.vegetation_health === 'good' ? 'good' :
                    analysis.vegetation_health === 'stressed' ? 'alert' : 'warning'} />
                <MetricTile label="Water Stress" value={analysis.water_stress}
                  status={analysis.water_stress === 'low' ? 'good' :
                    analysis.water_stress === 'moderate' ? 'warning' : 'alert'} />
              </div>
            </div>

            {/* Temperature */}
            <div>
              <SectionLabel>Temperature</SectionLabel>
              <div className="bg-card border border-border rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/30">
                      {['Metric', 'Value', 'vs Historical'].map(h => (
                        <th key={h} className="text-left px-4 py-2 text-xs font-medium text-muted-foreground"
                          style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-border">
                      <td className="px-4 py-2.5 text-foreground">This Season</td>
                      <td className="px-4 py-2.5" style={{ fontFamily: 'var(--font-mono)' }}>
                        {analysis.temperature_this_season} °C
                      </td>
                      <td className="px-4 py-2.5">
                        <AnomalyIndicator value={analysis.temperature_anomaly_c} unit=" °C" />
                      </td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2.5 text-muted-foreground">Historical Norm</td>
                      <td className="px-4 py-2.5 text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
                        {(analysis.temperature_this_season - analysis.temperature_anomaly_c).toFixed(1)} °C
                      </td>
                      <td className="px-4 py-2.5 text-xs text-muted-foreground">baseline</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Right: radar chart */}
          <div>
            <SectionLabel>Risk Profile</SectionLabel>
            <div className="bg-card border border-border rounded-lg p-4 h-[220px]">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData} margin={{ top: 10, right: 20, bottom: 10, left: 20 }}>
                  <PolarGrid stroke="rgba(0,0,0,0.07)" />
                  <PolarAngleAxis
                    dataKey="metric"
                    tick={{ fontSize: 10, fill: '#5C6358', fontFamily: 'var(--font-mono)' }}
                  />
                  <Radar
                    name="Risk"
                    dataKey="score"
                    stroke="#DC2626"
                    fill="#DC2626"
                    fillOpacity={0.15}
                    strokeWidth={1.5}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Rainfall section with chart */}
        <div className="mb-5">
          <SectionLabel>Rainfall</SectionLabel>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="md:col-span-2 bg-card border border-border rounded-lg overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/30">
                    {['Metric', 'Value', 'Anomaly'].map(h => (
                      <th key={h} className="text-left px-4 py-2 text-xs font-medium text-muted-foreground"
                        style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-border">
                    <td className="px-4 py-2.5 text-foreground">This Season</td>
                    <td className="px-4 py-2.5" style={{ fontFamily: 'var(--font-mono)' }}>
                      {analysis.rainfall_this_season} mm
                    </td>
                    <td className="px-4 py-2.5">
                      <AnomalyIndicator value={analysis.rainfall_anomaly_percent} unit="%" />
                    </td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2.5 text-muted-foreground">Historical Average</td>
                    <td className="px-4 py-2.5 text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
                      {analysis.historical_rainfall_avg} mm
                    </td>
                    <td className="px-4 py-2.5 text-xs text-muted-foreground">10-yr baseline</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="bg-card border border-border rounded-lg p-3 h-[130px]">
              <p className="text-xs text-muted-foreground uppercase mb-1"
                style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.05em', fontSize: '10px' }}>
                Rainfall Comparison (mm)
              </p>
              <ResponsiveContainer width="100%" height="85%">
                <BarChart data={rainfallChartData} barSize={32} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                  <CartesianGrid vertical={false} stroke="rgba(0,0,0,0.05)" />
                  <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#5C6358', fontFamily: 'var(--font-mono)' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 9, fill: '#5C6358', fontFamily: 'var(--font-mono)' }} axisLine={false} tickLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="value" radius={[3, 3, 0, 0]}>
                    {rainfallChartData.map((entry, i) => (
                      <Cell key={i} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Risk assessment */}
        <div className="mb-5">
          <SectionLabel>Risk Assessment</SectionLabel>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <RiskScoreCard label="Drought Risk" score={analysis.drought_score}
              level={analysis.drought_level} evidenceItems={droughtEvidence} />
            <RiskScoreCard label="Flood Risk" score={analysis.flood_score}
              level={analysis.flood_level} evidenceItems={floodEvidence} />
            <RiskScoreCard label="Heat Stress" score={analysis.heat_score}
              level={analysis.heat_level} evidenceItems={heatEvidence} />
          </div>
        </div>

        {/* Full evidence */}
        <div>
          <SectionLabel>All Evidence & Drivers</SectionLabel>
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <ul className="divide-y divide-border">
              {analysis.evidence.map((item, i) => (
                <li key={i} className="flex items-start gap-3 px-4 py-3">
                  <span className="text-xs text-muted-foreground flex-shrink-0 mt-0.5"
                    style={{ fontFamily: 'var(--font-mono)' }}>
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <p className="text-sm text-foreground">{item}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </PageContainer>
    </AppShell>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <h3 className="text-xs font-medium text-muted-foreground uppercase mb-2"
      style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.07em' }}>
      {children}
    </h3>
  );
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-md px-3 py-2 shadow-md text-xs">
      <p className="font-medium text-foreground mb-1">{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} style={{ color: p.fill, fontFamily: 'var(--font-mono)' }}>
          {p.value} mm
        </p>
      ))}
    </div>
  );
};
