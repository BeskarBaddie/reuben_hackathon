import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Save, Leaf } from 'lucide-react';
import { AppShell, PageContainer } from './AppShell';
import { MapPanel } from './MapPanel';
import { mockFarms } from '../mockData';
import type { Farm, IrrigationType, GeoJSONPolygon } from '../types';

interface FarmFormData {
  name: string;
  crop: string;
  planting_date: string;
  irrigation_type: IrrigationType;
  area_hectares: string;
  notes: string;
}

const irrigationOptions: { value: IrrigationType; label: string; description: string }[] = [
  { value: 'none', label: 'None', description: 'No irrigation at all' },
  { value: 'rainfed', label: 'Rainfed', description: 'Depends entirely on rainfall' },
  { value: 'partial', label: 'Partial', description: 'Some supplemental irrigation' },
  { value: 'full', label: 'Full', description: 'Full irrigation system' },
];

export function FarmForm() {
  const navigate = useNavigate();
  const { farmId } = useParams<{ farmId: string }>();
  const isEdit = Boolean(farmId);
  const existingFarm = farmId ? mockFarms.find(f => f.farm_id === farmId) : undefined;

  const [formData, setFormData] = useState<FarmFormData>({
    name: existingFarm?.name ?? '',
    crop: existingFarm?.crop ?? '',
    planting_date: existingFarm?.planting_date ?? '',
    irrigation_type: existingFarm?.irrigation_type ?? 'rainfed',
    area_hectares: existingFarm?.area_hectares?.toString() ?? '',
    notes: existingFarm?.notes ?? '',
  });
  const [boundary, setBoundary] = useState<GeoJSONPolygon | null>(existingFarm?.boundary ?? null);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof FarmFormData, string>>>({});

  function validate(): boolean {
    const errs: typeof errors = {};
    if (!formData.name.trim()) errs.name = 'Farm name is required';
    if (!formData.crop.trim()) errs.crop = 'Crop is required';
    if (!formData.planting_date) errs.planting_date = 'Planting date is required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function handleChange(field: keyof FarmFormData, value: string) {
    setFormData(prev => ({ ...prev, [field]: value }));
    setErrors(prev => ({ ...prev, [field]: undefined }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setSaving(true);
    // POST /api/v1/farms (or PUT for edit)
    await new Promise(r => setTimeout(r, 800));
    setSaving(false);
    navigate('/farms');
  }

  const breadcrumb = isEdit
    ? [{ label: 'Farms', href: '/farms' }, { label: existingFarm?.name ?? 'Edit Farm' }, { label: 'Edit' }]
    : [{ label: 'Farms', href: '/farms' }, { label: 'Add Farm' }];

  return (
    <AppShell breadcrumb={breadcrumb}>
      <PageContainer>
        <form onSubmit={handleSubmit} className="max-w-3xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            {/* Farm name */}
            <div className="md:col-span-2">
              <FieldGroup label="Farm Name" fieldId="name" error={errors.name} required>
                <input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={e => handleChange('name', e.target.value)}
                  placeholder="e.g. Nakato East Plot"
                  className={`w-full px-3 py-2 rounded-md text-sm bg-input-background border text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring transition-shadow ${errors.name ? 'border-destructive' : 'border-border'}`}
                />
              </FieldGroup>
            </div>

            {/* Crop */}
            <FieldGroup label="Crop" fieldId="crop" error={errors.crop} required>
              <input
                id="crop"
                type="text"
                value={formData.crop}
                onChange={e => handleChange('crop', e.target.value)}
                placeholder="e.g. Maize, Sorghum, Beans"
                className={`w-full px-3 py-2 rounded-md text-sm bg-input-background border text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring transition-shadow ${errors.crop ? 'border-destructive' : 'border-border'}`}
              />
            </FieldGroup>

            {/* Planting date */}
            <FieldGroup label="Planting Date" fieldId="planting_date" error={errors.planting_date} required>
              <input
                id="planting_date"
                type="date"
                value={formData.planting_date}
                onChange={e => handleChange('planting_date', e.target.value)}
                className={`w-full px-3 py-2 rounded-md text-sm bg-input-background border text-foreground outline-none focus:ring-2 focus:ring-ring transition-shadow ${errors.planting_date ? 'border-destructive' : 'border-border'}`}
                style={{ fontFamily: 'var(--font-mono)' }}
              />
            </FieldGroup>

            {/* Area */}
            <FieldGroup label="Area (hectares)" fieldId="area_hectares">
              <input
                id="area_hectares"
                type="number"
                min="0"
                step="0.1"
                value={formData.area_hectares}
                onChange={e => handleChange('area_hectares', e.target.value)}
                placeholder="e.g. 2.4"
                className="w-full px-3 py-2 rounded-md text-sm bg-input-background border border-border text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring transition-shadow"
                style={{ fontFamily: 'var(--font-mono)' }}
              />
            </FieldGroup>

            {/* Irrigation type */}
            <FieldGroup label="Irrigation Type" fieldId="irrigation_type">
              <div className="grid grid-cols-2 gap-2">
                {irrigationOptions.map(opt => (
                  <label
                    key={opt.value}
                    className={`flex items-start gap-2 p-2.5 rounded-md border cursor-pointer transition-colors ${
                      formData.irrigation_type === opt.value
                        ? 'border-accent bg-[#E8EDE6]'
                        : 'border-border bg-input-background hover:bg-muted'
                    }`}
                  >
                    <input
                      type="radio"
                      name="irrigation_type"
                      value={opt.value}
                      checked={formData.irrigation_type === opt.value}
                      onChange={() => handleChange('irrigation_type', opt.value)}
                      className="mt-0.5 accent-accent"
                    />
                    <div>
                      <p className="text-xs font-medium text-foreground">{opt.label}</p>
                      <p className="text-xs text-muted-foreground">{opt.description}</p>
                    </div>
                  </label>
                ))}
              </div>
            </FieldGroup>
          </div>

          {/* Farm description / notes */}
          <div className="mb-4">
            <FieldGroup
              label="Field Notes & Observations"
              fieldId="notes"
              hint="Describe what you know about this farm in your own words. This helps the system understand local context."
            >
              <div className="relative">
                <textarea
                  id="notes"
                  value={formData.notes}
                  onChange={e => handleChange('notes', e.target.value)}
                  rows={5}
                  placeholder={`Describe the farm in your own words. Include anything that's useful to know:\n\n• Soil type and condition (e.g. sandy, clay, thin, rocky)\n• Water access — streams, wells, boreholes nearby\n• Recent weather you've observed\n• Pest or disease problems\n• Parts of the field that have drainage issues or flood\n• Anything unusual about this season`}
                  className="w-full px-3 py-2.5 rounded-md text-sm bg-input-background border border-border text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring transition-shadow resize-y"
                  style={{ minHeight: '120px' }}
                />
                <div className="absolute bottom-2 right-2 flex items-center gap-1 text-muted-foreground">
                  <Leaf className="w-3 h-3" />
                  <span className="text-xs">field notes</span>
                </div>
              </div>
            </FieldGroup>
          </div>

          {/* Map boundary section */}
          <div className="mb-6">
            <div className="mb-1.5">
              <label className="text-sm font-medium text-foreground">Farm Boundary</label>
              <p className="text-xs text-muted-foreground mt-0.5">
                Draw the farm polygon on the map. Click to place points, click near the first point to close.
              </p>
            </div>
            <MapPanel
              boundary={boundary}
              onBoundaryChange={setBoundary}
              height={320}
            />
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:opacity-90 disabled:opacity-50 transition-opacity"
            >
              <Save className="w-4 h-4" />
              {saving ? 'Saving…' : isEdit ? 'Save Changes' : 'Save Farm'}
            </button>
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="px-4 py-2 border border-border bg-background text-foreground rounded-md text-sm hover:bg-muted transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </PageContainer>
    </AppShell>
  );
}

function FieldGroup({
  label,
  fieldId,
  children,
  error,
  hint,
  required,
}: {
  label: string;
  fieldId: string;
  children: React.ReactNode;
  error?: string;
  hint?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={fieldId} className="block text-sm font-medium text-foreground mb-1">
        {label}
        {required && <span className="text-destructive ml-0.5">*</span>}
      </label>
      {hint && <p className="text-xs text-muted-foreground mb-1.5">{hint}</p>}
      {children}
      {error && <p className="text-xs text-destructive mt-1">{error}</p>}
    </div>
  );
}
