export type IrrigationType = 'none' | 'rainfed' | 'partial' | 'full';
export type RiskLevel = 'low' | 'medium' | 'high' | 'critical' | 'unknown';
export type AnalysisStatus = 'pending' | 'running' | 'complete' | 'failed';
export type RecommendationProvider = 'deterministic' | 'openai' | 'ollama' | 'fallback';

export interface Farm {
  farm_id: string;
  name: string;
  crop: string;
  area_hectares: number;
  irrigation_type: IrrigationType;
  planting_date: string;
  notes: string;
  boundary: GeoJSONPolygon | null;
  last_updated: string;
  latest_risk?: RiskLevel;
  latest_analysis_id?: string;
}

export interface GeoJSONPolygon {
  type: 'Polygon';
  coordinates: number[][][];
}

export interface Analysis {
  analysis_id: string;
  farm_id: string;
  status: AnalysisStatus;
  created_at: string;
  ndvi: number;
  vegetation_health: string;
  water_stress: string;
  rainfall_this_season: number;
  historical_rainfall_avg: number;
  rainfall_anomaly_percent: number;
  temperature_this_season: number;
  temperature_anomaly_c: number;
  climate_signal: string;
  drought_score: number;
  drought_level: RiskLevel;
  flood_score: number;
  flood_level: RiskLevel;
  heat_score: number;
  heat_level: RiskLevel;
  overall_risk_level: RiskLevel;
  evidence: string[];
}

export interface RecommendationAction {
  priority: number;
  action: string;
  reason: string;
  evidence: string;
}

export interface Recommendations {
  analysis_id: string;
  provider: RecommendationProvider;
  model_name: string;
  prompt_version: string;
  summary: string;
  actions: RecommendationAction[];
  generated_at: string;
}
