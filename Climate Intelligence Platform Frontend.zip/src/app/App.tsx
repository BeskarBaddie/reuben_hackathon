import { BrowserRouter, Routes, Route } from 'react-router';
import { Dashboard } from './components/Dashboard';
import { FarmsList } from './components/FarmsList';
import { FarmForm } from './components/FarmForm';
import { FarmDetail } from './components/FarmDetail';
import { AnalysisReport } from './components/AnalysisReport';
import { Recommendations } from './components/Recommendations';
import { Settings } from './components/Settings';
import { NotFound } from './components/NotFound';

export default function App() {
  return (
    /* MARKER-MAKE-KIT-INVOKED */
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/farms" element={<FarmsList />} />
        <Route path="/farms/new" element={<FarmForm />} />
        <Route path="/farms/:farmId" element={<FarmDetail />} />
        <Route path="/farms/:farmId/edit" element={<FarmForm />} />
        <Route path="/analyses/:analysisId" element={<AnalysisReport />} />
        <Route path="/analyses/:analysisId/recommendations" element={<Recommendations />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}
