
  # Climate Intelligence Platform Frontend

  This is a code bundle for Climate Intelligence Platform Frontend. The original project is available at https://www.figma.com/design/lARx8exlNKcwo4FhZbNDOT/Climate-Intelligence-Platform-Frontend.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  